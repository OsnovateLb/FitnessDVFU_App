package com.example.androiddd

import androidx.lifecycle.LiveData

class ActivityRepository(private val activityDao: ActivityDao) {
    val allActivities: LiveData<List<ActivityEntity>> = activityDao.getAllActivities()

    suspend fun insertActivity(activity: ActivityEntity) {
        activityDao.insertActivity(activity)
    }
}