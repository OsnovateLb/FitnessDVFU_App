package com.example.androiddd

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel

class ActivityViewModel(private val repository: ActivityRepository) : ViewModel() {
    val allActivities: LiveData<List<ActivityEntity>> = repository.allActivities
}