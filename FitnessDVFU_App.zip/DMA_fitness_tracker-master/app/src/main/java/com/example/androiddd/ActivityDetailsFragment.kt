package com.example.androiddd

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.androiddd.databinding.FragmentActivityDetailsBinding

class ActivityDetailsFragment : Fragment() {
    private lateinit var binding: FragmentActivityDetailsBinding

    companion object {
        fun newInstance(activity: ActivityItem.Activity) = ActivityDetailsFragment().apply {
            arguments = Bundle().apply {
                putString("username", activity.username)
                putString("distance", activity.distance)
                putString("duration", activity.duration)
                putString("type", activity.type)
                putString("timeAgo", activity.timeAgo)
//                putString("startTime", activity.startTime)
//                putString("endTime", activity.endTime)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentActivityDetailsBinding.inflate(inflater, container, false)

        binding.tvUsername.text = arguments?.getString("username", "")
        binding.tvDistance.text = arguments?.getString("distance", "")
        binding.tvDuration.text = arguments?.getString("duration", "")
        binding.tvActivityType.title = arguments?.getString("type", "")
        binding.tvTimeAgo.text = arguments?.getString("timeAgo", "")
//        binding.tvStart.text = arguments?.getString("startTime", "")
//        binding.tvFinish.text = arguments?.getString("endTime", "")
        binding.tvActivityType.setNavigationOnClickListener {
            parentFragmentManager.popBackStack()
        }
        return binding.root
    }
}