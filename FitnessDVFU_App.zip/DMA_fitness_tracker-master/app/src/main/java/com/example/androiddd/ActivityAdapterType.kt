package com.example.androiddd

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class ActivityAdapterType(
    private val activities: List<ActivityItem>,
    private val onItemClick: (ActivityItem) -> Unit
) : RecyclerView.Adapter<ActivityAdapterType.ActivityViewHolder>() {

    data class ActivityItem(
        val name: String,
        val iconRes: Int,
        val getActivityType: () -> ActivityType
    )

    private var selectedPosition = -1

    inner class ActivityViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val name: TextView = itemView.findViewById(R.id.activityName)
        private val icon: ImageView = itemView.findViewById(R.id.activityIcon)

        fun bind(activity: ActivityItem, isSelected: Boolean) {
            name.text = activity.name
            icon.setImageResource(activity.iconRes)
            itemView.background = ContextCompat.getDrawable(
                itemView.context,
                if (isSelected) R.drawable.card_selected else R.drawable.card_unselected
            )
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ActivityViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_activity_variant, parent, false)
        return ActivityViewHolder(view)
    }

    override fun onBindViewHolder(holder: ActivityViewHolder, position: Int) {
        val activity = activities[position]
        holder.bind(activity, position == selectedPosition)

        holder.itemView.setOnClickListener {
            val previousPosition = selectedPosition
            selectedPosition = holder.adapterPosition
            notifyItemChanged(previousPosition)
            notifyItemChanged(selectedPosition)
            onItemClick(activity)
        }
    }

    override fun getItemCount(): Int {
        return activities.size
    }
}