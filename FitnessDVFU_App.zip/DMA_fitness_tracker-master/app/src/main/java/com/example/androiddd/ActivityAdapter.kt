package com.example.androiddd

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ActivityAdapter(
    private val items: List<ActivityItem>,
    private val onItemClick: (ActivityItem.Activity) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun getItemViewType(position: Int): Int {
        return when (items[position]) {
            is ActivityItem.DateHeader -> R.layout.item_date_header
            is ActivityItem.Activity -> R.layout.item_activity
        }
    }

    override fun getItemCount(): Int {
        return items.count();
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            R.layout.item_date_header -> DateHeaderViewHolder(
                LayoutInflater.from(parent.context).inflate(viewType, parent, false)
            )
            else -> ActivityViewHolder(
                LayoutInflater.from(parent.context).inflate(viewType, parent, false)
            )
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = items[position]) {
            is ActivityItem.DateHeader -> (holder as DateHeaderViewHolder).bind(item.date)
            is ActivityItem.Activity -> {
                (holder as ActivityViewHolder).bind(item)
                holder.itemView.setOnClickListener { onItemClick(item) }
            }
        }
    }

    inner class DateHeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bind(date: String) {
            itemView.findViewById<TextView>(R.id.tv_date).text = date
        }
    }

    inner class ActivityViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bind(activity: ActivityItem.Activity) {
            itemView.findViewById<TextView>(R.id.tv_distance).text = activity.distance
            itemView.findViewById<TextView>(R.id.tv_time_ago).text = activity.timeAgo
            itemView.findViewById<TextView>(R.id.tv_duration).text = activity.duration
            itemView.findViewById<TextView>(R.id.tv_activity_type).text = activity.type
            itemView.findViewById<TextView>(R.id.tv_username).text = activity.username
        }
    }
}