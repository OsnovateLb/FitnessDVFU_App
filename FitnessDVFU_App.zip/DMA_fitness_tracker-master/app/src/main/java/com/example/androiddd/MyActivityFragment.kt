package com.example.androiddd

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MyActivityFragment : Fragment() {
    private lateinit var viewModel: ActivityViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_my_activity, container, false)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        val repository = ActivityRepository(AppDatabase.getDatabase(requireContext()).activityDao())
        val viewModelFactory = ActivityViewModelFactory(repository)
        viewModel = ViewModelProvider(this, viewModelFactory).get(ActivityViewModel::class.java)

        viewModel.allActivities.observe(viewLifecycleOwner) { activities ->
            val items = convertToActivityItems(activities)
            recyclerView.adapter = ActivityAdapter(items) { activity ->
                requireActivity().supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, ActivityDetailsFragment.newInstance(activity))
                    .addToBackStack("activity_details")
                    .commit()
            }
        }

        return view
    }

    private fun convertToActivityItems(activities: List<ActivityEntity>): List<ActivityItem> {
        val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val dateHeaderFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())

        val items = mutableListOf<ActivityItem>()
        var currentHeader: String? = null

        activities.forEach { activity ->
            val header = dateHeaderFormat.format(activity.startTime)
            if (header != currentHeader) {
                items.add(ActivityItem.DateHeader(header))
                currentHeader = header
            }

            val distanceKm = "%.2f км".format(calculateDistance(activity.coordinates))
            val duration = formatDuration(activity.startTime, activity.endTime)
            val timeAgo = formatTimeAgo(activity.endTime)
            val type = when (activity.type) {
                ActivityType.CYCLING -> "Велосипед"
                ActivityType.RUNNING -> "Бег"
                ActivityType.WALKING -> "Шаг"
            }

            items.add(ActivityItem.Activity(
                distance = distanceKm,
                duration = duration,
                type = type,
                timeAgo = timeAgo,
                username = ""
            ))
        }

        return items
    }

    private fun calculateDistance(coordinates: List<ActivityEntity.Coordinate>): Double {
        if (coordinates.size < 2) return 0.0
        var distance = 0.0
        for (i in 1 until coordinates.size) {
            val prev = coordinates[i-1]
            val curr = coordinates[i]
            distance += haversine(prev.latitude, prev.longitude, curr.latitude, curr.longitude)
        }
        return distance / 1000
    }

    private fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val R = 6371000
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return R * c
    }

    private fun formatDuration(start: Date, end: Date): String {
        val duration = end.time - start.time
        val seconds = (duration / 1000) % 60
        val minutes = (duration / (1000 * 60)) % 60
        val hours = duration / (1000 * 60 * 60)
        return "%d:%02d:%02d".format(hours, minutes, seconds)
    }

    private fun formatTimeAgo(endTime: Date): String {
        val now = Date()
        val diff = now.time - endTime.time
        val seconds = diff / 1000
        val minutes = seconds / 60
        val hours = minutes / 60
        val days = hours / 24

        return when {
            days > 0 -> "$days дней назад"
            hours > 0 -> "$hours часов назад"
            minutes > 0 -> "$minutes минут назад"
            else -> "только что"
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() = MyActivityFragment()
    }
}