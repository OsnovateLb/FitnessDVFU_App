package com.example.androiddd

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class UsersActivityFragment : Fragment() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {}
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_users_activity, container, false)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view)

        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        val items = listOf(
            ActivityItem.DateHeader("Вчера"),
            ActivityItem.Activity("15.9 км", "1 часа 59 минут", "Утром учеба, вечером серфинг", "9 часов назад", "@mesenev"),
            ActivityItem.Activity("228 м", "1 часов 45 минут", "Анжуманя", "14 часов назад", "@kama_pula"),
            ActivityItem.Activity("100 км", "1 час 10 минут", "Поездка на Дайхатсу", "14 часов назад", "@me"),
        )

        recyclerView.adapter = ActivityAdapter(items) { activity ->
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, ActivityDetailsFragment.newInstance(activity))
                .addToBackStack("activity_details")
                .commit()
        }

        return view
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            UsersActivityFragment().apply {
                arguments = Bundle().apply {}
            }
    }
}