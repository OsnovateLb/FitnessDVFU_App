package com.example.androiddd

sealed class ActivityItem {
    data class DateHeader(val date: String) : ActivityItem()
    data class Activity(
        val distance: String,
        val duration: String,
        val type: String,
        val timeAgo: String,
        val username: String
    ) : ActivityItem()
}