package com.example.androiddd

enum class ActivityType {
    CYCLING,
    RUNNING,
    WALKING
}