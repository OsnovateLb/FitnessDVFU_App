package com.example.androiddd

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.androiddd.databinding.ActivityStartActivityBinding
import kotlinx.coroutines.launch
import java.util.Date

class StartActivityActivity : AppCompatActivity() {
    private lateinit var binding: ActivityStartActivityBinding
    private lateinit var activityAdapter: ActivityAdapterType
    private var selectedActivity: ActivityAdapterType.ActivityItem? = null
    private lateinit var repository: ActivityRepository

    private val activities = listOf(
        ActivityAdapterType.ActivityItem("Велосипед", R.drawable.ic_welcome) { ActivityType.CYCLING },
        ActivityAdapterType.ActivityItem("Бег", R.drawable.ic_welcome) { ActivityType.RUNNING },
        ActivityAdapterType.ActivityItem("Шаг", R.drawable.ic_welcome) { ActivityType.WALKING }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStartActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val db = AppDatabase.getDatabase(this)
        repository = ActivityRepository(db.activityDao())

        setupRecyclerView()
        setupClickListeners()
    }

    private fun setupRecyclerView() {
        activityAdapter = ActivityAdapterType(activities) { activity ->
            selectedActivity = activity
        }

        binding.activitiesRecyclerView.apply {
            layoutManager = LinearLayoutManager(
                this@StartActivityActivity,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            adapter = activityAdapter
        }
    }

    private fun setupClickListeners() {
        binding.backButton.setOnClickListener {
            finish()
        }

        binding.start.setOnClickListener {
            selectedActivity?.let { activity ->
                showActivityStartedView(activity.name)
                saveActivity(activity.getActivityType())
            }
        }
    }

    private fun saveActivity(type: ActivityType) {
        lifecycleScope.launch {
            val startTime = Date()
            val endTime = Date(startTime.time + 60 * 60 * 1000)

            val coordinates = List(10) { i ->
                val progress = i / 9.0
                ActivityEntity.Coordinate(
                    latitude = 55.7522 + progress * 0.1,
                    longitude = 37.6156 + progress * 0.1
                )
            }

            val activity = ActivityEntity(
                type = type,
                startTime = startTime,
                endTime = endTime,
                coordinates = coordinates
            )

            repository.insertActivity(activity)
        }
    }

    private fun showActivityStartedView(activityName: String) {
        binding.activityPanel.removeAllViews()
        val startedView = layoutInflater.inflate(
            R.layout.layout_activity_started,
            binding.activityPanel,
            true
        )

        startedView.findViewById<TextView>(R.id.activity_title).text = activityName
        startedView.findViewById<TextView>(R.id.distance).text = "14 км"
        startedView.findViewById<TextView>(R.id.time).text = "00:01:46"

        startedView.findViewById<ImageButton>(R.id.finish_button).setOnClickListener {
            finish()
        }
    }
}